# VerityFlow — Round 2 submission notes

## Project
**VerityFlow: Evidence-first brand governance for every draft**  
Team: VerityFlow Labs  
Participant: Mahesh Guntipally  
Demo brand: Northstar Energy (fictional)

## Working project link
Open `index.html` from the source package to run the local interactive prototype. A public hosting URL has **not** been created from this environment. Publish this static site with the included GitHub Pages workflow, then replace this line with the verified public URL before submission.

## Source-code repository link
The source-ready repository package is `verityflow-brand-governance.zip`. A public GitHub repository has **not** been created or pushed from this environment. Create the repository, upload the package contents, and insert the verified repository URL before submission.

## Updated project PDF
See `VerityFlow_Updated_Project_Submission.pdf` (delivered separately in the parent folder).

## Completed features
- Five-page responsive app: Overview, Review Studio, Source Library, Review Queue, Audit Trail.
- Draft content editor, demo sample loader, `.txt`/`.md` import, word and character counters.
- Rule-based flags for numeric claim evidence, absolute promises, unsupported ranking/comparison, and unsubstantiated outcome language.
- Source / rule evidence displayed with each finding; explicit evidence-boundary status labels.
- Suggested minimal edits with re-analysis.
- Local editable source library with dates, owner, expiry/review date and scope notes.
- Submission queue with snapshot of content and findings; approve or request changes in Reviewer view.
- Approval reset when approved draft text is edited; decisions recorded in local audit trail.
- JSON export of review report and audit events.
- Synthetic demo workspace, transparent limitation notices, keyboard focus states, responsive layout.

## Technology / implementation
- HTML5 + CSS3 + vanilla JavaScript; no build step required.
- Browser localStorage for demo state; FileReader for text import; Blob downloads for JSON export.
- Deterministic local checks and synthetic approved-source ledger; no external AI calls or API credentials.
- Static-host compatible and includes GitHub Pages workflow.

## Changes from original plan
The plan proposed Next.js/React, FastAPI, a database/auth layer, an AI provider adapter, OCR, and a richer source retrieval system. For this build, implementation was narrowed to a no-dependency static prototype so that a complete end-to-end journey could be demonstrated without credentials or external services. Therefore live LLM claim extraction, backend persistence, real access control, OCR/DOCX/PDF handling, logo/colour analysis, and production-grade audit protections are not claimed as completed. The product retains the evidence-first Claim Passport, minimal edits, human review, version binding, and audit workflow as its core story.

## Three major improvements planned for Round 3
1. **Evidence-grounded claim extraction:** provider adapter + constrained output + approved-source retrieval + deterministic validation, with unknowns clearly labelled.
2. **Secure version-aware governance:** server-side persistence, real authentication/role checks, immutable submitted versions, and approval-invalidation regression tests.
3. **Visual/accessibility validation and measured benchmark:** supported OCR/image checks, basic asset/alt-text checks, seeded test benchmark, user walkthroughs, and honest publication of measured results/failure cases.

## Test result

The current local prototype passed 22/22 scripted browser acceptance checks, including source addition, Markdown import, JSON exports, reviewer approval, request-changes with a reason, approval invalidation after editing, and 390 px responsive overflow checks. These are functional acceptance checks, not a claim of production accuracy or security.

## Honest status
This is a functional local prototype. The public URL and public repository URL remain to be created and verified by the participant. Demo statistics are not measured user outcomes. All brand/source records are synthetic. The application is not a universal truth verifier or legal compliance system.
